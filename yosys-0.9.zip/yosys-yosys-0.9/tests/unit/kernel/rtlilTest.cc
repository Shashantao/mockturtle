#include <gtest/gtest.h>

#include "kernel/yosys.h"
#include "kernel/rtlil.h"

YOSYS_NAMESPACE_BEGIN

TEST(KernelRtlilTest, getReferenceValid)
{
	//TODO: Implement rtlil test
	EXPECT_EQ(33, 33);
}

YOSYS_NAMESPACE_END
